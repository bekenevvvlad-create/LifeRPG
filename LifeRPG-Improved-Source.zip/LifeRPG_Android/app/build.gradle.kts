plugins { id("com.android.application") }

android {
    namespace = "com.liferpg.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.liferpg.app"
        minSdk = 26
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            isShrinkResources = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
